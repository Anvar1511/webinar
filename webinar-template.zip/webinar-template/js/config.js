/**
 * ═══════════════════════════════════════════════════════════════
 * 🎯 WEBINAR LANDING PAGE KONFIGURATSIYASI
 * ═══════════════════════════════════════════════════════════════
 * 
 * Bu faylda BARCHA o'zgaruvchan ma'lumotlar joylashgan.
 * Yangi webinar uchun FAQAT shu faylni o'zgartiring!
 * 
 * Tayyor bo'lgach config.js ni o'zgartiring va sayt tayyor!
 */

const CONFIG = {
    
    // ═══════════════════════════════════════════════════════════
    // 📌 ASOSIY MA'LUMOTLAR
    // ═══════════════════════════════════════════════════════════
    
    webinar: {
        // Sahifa sarlavhasi (browser tab da ko'rinadi)
        pageTitle: "Prezident maktabiga samarali tayyorlanish | Bepul webinar",
        
        // Asosiy sarlavha (hero section)
        headline: "Prezident maktabiga samarali tayyorlanish",
        
        // Qo'shimcha sarlavha (subheadline)
        subheadline: "Farzandingiz PM ga 90% ehtimollik bilan kiradi — professional usullar bilan",
        
        // Kategoriya yoki mavzu (yuqorida kichik matn)
        category: "Prezident maktabi",
        
        // Sana va vaqt
        date: "9-10 dekabr",
        time: "20:30",
        
        // Davomiyligi (ixtiyoriy)
        duration: "2 kun",
    },

    // ═══════════════════════════════════════════════════════════
    // 👤 MENTOR MA'LUMOTLARI
    // ═══════════════════════════════════════════════════════════
    
    mentor: {
        name: "Adham Sohibov",
        title: "Prezident maktabi bo'yicha ekspert",
        
        // Mentor rasmi (img papkasiga joylashtiring)
        // Placeholder: img/mentor.svg | O'zingizni qo'ying: img/mentor.webp
        photo: "img/mentor.svg",
        
        // Qisqacha biografiya
        bio: "10+ yillik tajriba, 500+ o'quvchi PM ga kirdi",
        
        // Yutuqlar (badges)
        achievements: [
            "500+ muvaffaqiyatli o'quvchi",
            "10 yillik tajriba",
            "PM metodisti"
        ]
    },

    // ═══════════════════════════════════════════════════════════
    // 💰 NARX VA URGENCY
    // ═══════════════════════════════════════════════════════════
    
    pricing: {
        // Eski narx (chiziladi)
        originalPrice: "299 000",
        
        // Hozirgi narx
        currentPrice: "BEPUL",
        
        // Valyuta
        currency: "so'm",
        
        // Chegirma foizi (ixtiyoriy)
        discount: "100%"
    },
    
    urgency: {
        // Qolgan joylar soni
        spotsLeft: 47,
        
        // Jami joylar
        totalSpots: 100,
        
        // Timer tugash vaqti (ISO format)
        // Misol: "2024-12-10T20:30:00" yoki relative: hours, minutes
        timerEndDate: null, // null bo'lsa, quyidagilar ishlatiladi
        timerHours: 23,
        timerMinutes: 59,
        timerSeconds: 59,
        
        // Urgency matnlari
        urgencyText: "Shoshiling! Joylar soni oz qoldi",
        timerLabel: "Ro'yxatdan o'tish uchun qolgan vaqt:"
    },

    // ═══════════════════════════════════════════════════════════
    // 📚 WEBINARDA NIMALARNI O'RGANASIZ
    // ═══════════════════════════════════════════════════════════
    
    benefits: [
        {
            icon: "🎯",
            title: "Samarali tayyorgarlik strategiyasi",
            description: "Farzandingizni qanday qilib PM ga samarali tayyorlash"
        },
        {
            icon: "📝",
            title: "Test yechish texnikalari",
            description: "Test savollarini to'g'ri va tez yechish sirlari"
        },
        {
            icon: "🧠",
            title: "Tanqidiy fikrlash",
            description: "Farzandingizning mustaqil fikrlashini o'stirish usullari"
        },
        {
            icon: "⏰",
            title: "Vaqtni boshqarish",
            description: "Imtihonda vaqtni to'g'ri taqsimlash strategiyasi"
        }
    ],

    // ═══════════════════════════════════════════════════════════
    // 🎁 SOVG'ALAR
    // ═══════════════════════════════════════════════════════════
    
    gifts: {
        enabled: true,
        title: "Qatnashuvchilar uchun maxsus sovg'alar:",
        items: [
            "📘 PM test namunalari to'plami (PDF)",
            "🎥 Test yechish video qo'llanma",
            "📋 Kunlik tayyorgarlik rejasi shabloni",
            "✅ Individual maslahat imkoniyati"
        ]
    },

    // ═══════════════════════════════════════════════════════════
    // 💬 TESTIMONIALLAR (Ijtimoiy tasdiqlash)
    // ═══════════════════════════════════════════════════════════
    
    testimonials: {
        enabled: true,
        title: "Ota-onalar fikrlari:",
        items: [
            {
                name: "Nilufar A.",
                role: "O'g'li PM ga kirdi",
                photo: "img/testimonial-1.webp", // yoki null
                text: "Adham akaning usullari tufayli o'g'lim PM ga muammosiz kirdi. Juda samarali metodika!",
                rating: 5
            },
            {
                name: "Sardor T.",
                role: "Qizi PM o'quvchisi",
                photo: "img/testimonial-2.webp",
                text: "2 oy ichida qizimning test natijalari 40% yaxshilandi. Tavsiya qilaman!",
                rating: 5
            },
            {
                name: "Madina K.",
                role: "Ikki farzand onasi",
                photo: "img/testimonial-3.webp",
                text: "Birinchi marta aniq va tushunarli yo'l-yo'riq oldim. Rahmat!",
                rating: 5
            }
        ]
    },

    // ═══════════════════════════════════════════════════════════
    // 📊 STATISTIKA (Social Proof)
    // ═══════════════════════════════════════════════════════════
    
    stats: {
        enabled: true,
        items: [
            { number: "500+", label: "Muvaffaqiyatli o'quvchi" },
            { number: "95%", label: "Qoniqish darajasi" },
            { number: "10+", label: "Yillik tajriba" },
            { number: "50+", label: "Bugun ro'yxatdan o'tdi" }
        ]
    },

    // ═══════════════════════════════════════════════════════════
    // ❓ KO'P SO'RALADIGAN SAVOLLAR (FAQ)
    // ═══════════════════════════════════════════════════════════
    
    faq: {
        enabled: true,
        title: "Ko'p so'raladigan savollar",
        items: [
            {
                question: "Webinar qayerda bo'ladi?",
                answer: "Webinar Telegram orqali bo'ladi. Ro'yxatdan o'tganingizdan so'ng sizga link yuboriladi."
            },
            {
                question: "Yozib olingan versiyasi bo'ladimi?",
                answer: "Ha, barcha qatnashuvchilarga yozuv taqdim etiladi."
            },
            {
                question: "Qaysi yoshdagi bolalar uchun mos?",
                answer: "Prezident maktabiga kirish yoshidagi bolalar uchun, asosan 6-7 yoshlilar."
            }
        ]
    },

    // ═══════════════════════════════════════════════════════════
    // 📝 FORMA SOZLAMALARI
    // ═══════════════════════════════════════════════════════════
    
    form: {
        // Placeholder matnlar
        phonePlaceholder: "Telefon raqamingiz",
        namePlaceholder: "Ismingiz", // nameEnabled: true bo'lsa
        
        // Qaysi maydonlar kerak
        nameEnabled: false,
        emailEnabled: false,
        
        // Submit tugmasi matni
        submitButton: "BEPUL QATNASHISH",
        
        // Muvaffaqiyat xabari
        successMessage: "Tabriklaymiz! Siz muvaffaqiyatli ro'yxatdan o'tdingiz. Tez orada siz bilan bog'lanamiz!",
        
        // Xatolik xabari
        errorMessage: "Xatolik yuz berdi. Iltimos, qaytadan urinib ko'ring.",
        
        // Telefon validatsiya
        phonePattern: "^\\+998[0-9]{9}$",
        phoneError: "Telefon raqam noto'g'ri formatda. Misol: +998901234567",
        
        // Form action URL (webhook, API endpoint, yoki Google Sheets)
        actionUrl: "https://your-webhook-url.com/submit",
        
        // Yoki Telegram bot
        telegramBotToken: "",
        telegramChatId: "",
        
        // Privacy policy
        privacyText: "Ro'yxatdan o'tish orqali siz shaxsiy ma'lumotlaringizni qayta ishlashga rozilik bildirasiz",
        privacyLink: "#"
    },

    // ═══════════════════════════════════════════════════════════
    // 🎨 DIZAYN SOZLAMALARI
    // ═══════════════════════════════════════════════════════════
    
    design: {
        // Asosiy ranglar
        primaryColor: "#E63946",      // CTA tugmalar, accent
        secondaryColor: "#1D3557",    // Sarlavhalar, matn
        accentColor: "#F4A261",       // Highlights, badges
        backgroundColor: "#F8F9FA",   // Fon rangi
        cardBackground: "#FFFFFF",    // Kartalar foni
        textColor: "#2B2D42",         // Asosiy matn
        lightText: "#6C757D",         // Ikkinchi darajali matn
        
        // Gradient (hero section uchun)
        gradientStart: "#1D3557",
        gradientEnd: "#457B9D",
        
        // Border radius
        borderRadius: "12px",
        buttonRadius: "50px",
        
        // Font family (Google Fonts)
        headingFont: "'Montserrat', sans-serif",
        bodyFont: "'Open Sans', sans-serif",
        
        // Logo (ixtiyoriy)
        logo: null, // "img/logo.png" yoki null
        
        // Favicon
        favicon: "img/favicon.ico",
        
        // Background pattern yoki image
        heroBackground: null, // "img/hero-bg.jpg" yoki null
        useGradient: true,
        
        // Animations
        animationsEnabled: true
    },

    // ═══════════════════════════════════════════════════════════
    // 📱 IJTIMOIY TARMOQLAR
    // ═══════════════════════════════════════════════════════════
    
    social: {
        telegram: "https://t.me/your_channel",
        instagram: "https://instagram.com/your_account",
        youtube: "",
        facebook: ""
    },

    // ═══════════════════════════════════════════════════════════
    // 📊 ANALYTICS
    // ═══════════════════════════════════════════════════════════
    
    analytics: {
        // Facebook Pixel
        facebookPixelId: "YOUR_PIXEL_ID_HERE",
        
        // Google Analytics
        googleAnalyticsId: "",
        
        // Yandex Metrika
        yandexMetrikaId: "",
        
        // TikTok Pixel
        tiktokPixelId: ""
    },

    // ═══════════════════════════════════════════════════════════
    // 🌐 TIL VA LOKALIZATSIYA
    // ═══════════════════════════════════════════════════════════
    
    locale: {
        language: "uz",
        dateFormat: "DD MMMM",
        timeFormat: "HH:mm",
        
        // UI matnlari
        texts: {
            registrationTitle: "Ro'yxatdan o'tish",
            spotsLeft: "joy qoldi",
            todayRegistered: "Bugun ro'yxatdan o'tdi:",
            benefitsTitle: "Webinarda nimalarni o'rganasiz?",
            submitLoading: "Yuborilmoqda...",
            days: "kun",
            hours: "soat",
            minutes: "daqiqa",
            seconds: "soniya"
        }
    },

    // ═══════════════════════════════════════════════════════════
    // 🔧 QILISHIMCHA SOZLAMALAR
    // ═══════════════════════════════════════════════════════════
    
    advanced: {
        // Auto-scroll to form after X seconds
        autoScrollToForm: false,
        autoScrollDelay: 30000, // 30 sekund
        
        // Exit intent popup
        exitIntentEnabled: false,
        exitIntentMessage: "Ketmoqchimisiz? Maxsus chegirmani qo'ldan boy bermang!",
        
        // Countdown urgency - spots decreasing
        dynamicSpots: true,
        spotsDecreaseInterval: 300000, // 5 daqiqada 1 ta kamayadi
        
        // Form pre-fill from URL params
        urlParamPrefill: true,
        
        // Debug mode
        debugMode: false
    }
};

// Export for modules (agar kerak bo'lsa)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}
