/**
 * ═══════════════════════════════════════════════════════════════
 * 🚀 WEBINAR LANDING PAGE - JAVASCRIPT
 * ═══════════════════════════════════════════════════════════════
 * Barcha funksionallik va dinamik kontentni boshqarish
 */

// ═══════════════════════════════════════════════════════════════
// 🎯 INITIALIZATION
// ═══════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', function() {
    // Check if CONFIG exists
    if (typeof CONFIG === 'undefined') {
        console.error('CONFIG not found! Please check config.js');
        return;
    }
    
    // Initialize all modules
    initPageContent();
    initCountdownTimer();
    initSpotsCounter();
    initForm();
    initFAQ();
    initTestimonialsSlider();
    initStickyCTA();
    initExitIntent();
    initAnalytics();
    initAnimations();
    initCountrySelector();
    
    // Debug mode
    if (CONFIG.advanced.debugMode) {
        console.log('CONFIG loaded:', CONFIG);
    }
});

// ═══════════════════════════════════════════════════════════════
// 📝 PAGE CONTENT INITIALIZATION
// ═══════════════════════════════════════════════════════════════

function initPageContent() {
    // Page title
    document.title = CONFIG.webinar.pageTitle;
    
    // Meta tags
    updateMetaTags();
    
    // Hero section
    setText('categoryBadge', CONFIG.webinar.category);
    setText('eventDate', CONFIG.webinar.date);
    setText('eventTime', CONFIG.webinar.time);
    setText('heroHeadline', CONFIG.webinar.headline);
    setText('heroSubheadline', CONFIG.webinar.subheadline);
    
    // Mentor
    setText('mentorName', CONFIG.mentor.name);
    setText('mentorTitle', CONFIG.mentor.title);
    setText('mentorBio', CONFIG.mentor.bio);
    setImage('mentorPhoto', CONFIG.mentor.photo, CONFIG.mentor.name);
    
    // Pricing
    const originalPrice = document.getElementById('originalPrice');
    if (originalPrice) {
        originalPrice.textContent = `${CONFIG.pricing.originalPrice} ${CONFIG.pricing.currency}`;
    }
    setText('currentPrice', CONFIG.pricing.currentPrice);
    setText('discountBadge', `-${CONFIG.pricing.discount}`);
    setText('stickyPrice', CONFIG.pricing.currentPrice);
    
    // Urgency
    setText('urgencyText', CONFIG.urgency.urgencyText);
    setText('timerLabel', CONFIG.urgency.timerLabel);
    
    // Stats
    if (CONFIG.stats.enabled) {
        renderStats();
    } else {
        hideElement('statsSection');
    }
    
    // Benefits
    renderBenefits();
    
    // Gifts
    if (CONFIG.gifts.enabled) {
        setText('giftsTitle', CONFIG.gifts.title);
        renderGifts();
    } else {
        hideElement('giftsSection');
    }
    
    // Testimonials
    if (CONFIG.testimonials.enabled) {
        setText('testimonialsTitle', CONFIG.testimonials.title);
        renderTestimonials();
    } else {
        hideElement('testimonialsSection');
    }
    
    // FAQ
    if (CONFIG.faq.enabled) {
        setText('faqTitle', CONFIG.faq.title);
        renderFAQ();
    } else {
        hideElement('faqSection');
    }
    
    // Form settings
    if (CONFIG.form.nameEnabled) {
        showElement('nameGroup');
    }
    if (CONFIG.form.emailEnabled) {
        showElement('emailGroup');
    }
    
    const submitBtn = document.querySelector('.submit-button .button-text');
    if (submitBtn) {
        submitBtn.textContent = CONFIG.form.submitButton;
    }
    setText('privacyText', CONFIG.form.privacyText);
    setText('successText', CONFIG.form.successMessage);
    
    // Social links
    renderSocialLinks();
    
    // Footer year
    setText('currentYear', new Date().getFullYear());
    
    // Apply design settings
    applyDesignSettings();
}

function updateMetaTags() {
    // OG tags
    const ogTitle = document.querySelector('meta[property="og:title"]');
    const ogDescription = document.querySelector('meta[property="og:description"]');
    
    if (ogTitle) ogTitle.setAttribute('content', CONFIG.webinar.pageTitle);
    if (ogDescription) ogDescription.setAttribute('content', CONFIG.webinar.subheadline);
}

function applyDesignSettings() {
    const root = document.documentElement;
    const design = CONFIG.design;
    
    // Apply colors
    root.style.setProperty('--primary', design.primaryColor);
    root.style.setProperty('--secondary', design.secondaryColor);
    root.style.setProperty('--accent', design.accentColor);
    root.style.setProperty('--background', design.backgroundColor);
    root.style.setProperty('--card-bg', design.cardBackground);
    root.style.setProperty('--text-primary', design.textColor);
    root.style.setProperty('--text-secondary', design.lightText);
    root.style.setProperty('--gradient-start', design.gradientStart);
    root.style.setProperty('--gradient-end', design.gradientEnd);
    root.style.setProperty('--radius-md', design.borderRadius);
    root.style.setProperty('--radius-full', design.buttonRadius);
    root.style.setProperty('--font-heading', design.headingFont);
    root.style.setProperty('--font-body', design.bodyFont);
    
    // Favicon
    if (design.favicon) {
        const favicon = document.querySelector('link[rel="icon"]');
        if (favicon) favicon.href = design.favicon;
    }
    
    // Logo
    if (design.logo) {
        // Add logo element if exists
    }
}

// ═══════════════════════════════════════════════════════════════
// ⏰ COUNTDOWN TIMER
// ═══════════════════════════════════════════════════════════════

let countdownInterval;

function initCountdownTimer() {
    let endTime;
    const storageKey = 'webinar_timer_' + CONFIG.webinar.headline.substring(0, 20).replace(/\s/g, '_');
    
    if (CONFIG.urgency.timerEndDate) {
        endTime = new Date(CONFIG.urgency.timerEndDate).getTime();
    } else {
        // Use hours, minutes, seconds from config
        const storedEndTime = localStorage.getItem(storageKey);
        if (storedEndTime && parseInt(storedEndTime) > new Date().getTime()) {
            endTime = parseInt(storedEndTime);
        } else {
            endTime = new Date().getTime() + 
                (CONFIG.urgency.timerHours * 60 * 60 * 1000) +
                (CONFIG.urgency.timerMinutes * 60 * 1000) +
                (CONFIG.urgency.timerSeconds * 1000);
            localStorage.setItem(storageKey, endTime);
        }
    }
    
    function updateTimer() {
        const now = new Date().getTime();
        const distance = endTime - now;
        
        if (distance < 0) {
            clearInterval(countdownInterval);
            document.getElementById('countdownHours').textContent = '00';
            document.getElementById('countdownMinutes').textContent = '00';
            document.getElementById('countdownSeconds').textContent = '00';
            return;
        }
        
        const hours = Math.floor(distance / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        document.getElementById('countdownHours').textContent = padZero(hours);
        document.getElementById('countdownMinutes').textContent = padZero(minutes);
        document.getElementById('countdownSeconds').textContent = padZero(seconds);
    }
    
    updateTimer();
    countdownInterval = setInterval(updateTimer, 1000);
}

function padZero(num) {
    return num < 10 ? '0' + num : num;
}

// ═══════════════════════════════════════════════════════════════
// 🔥 SPOTS COUNTER
// ═══════════════════════════════════════════════════════════════

let spotsLeft = CONFIG.urgency.spotsLeft;

function initSpotsCounter() {
    updateSpotsDisplay();
    
    // Dynamic spots decreasing
    if (CONFIG.advanced.dynamicSpots) {
        const storedSpots = localStorage.getItem('webinar_spots');
        if (storedSpots) {
            spotsLeft = parseInt(storedSpots);
        }
        
        setInterval(() => {
            if (spotsLeft > 5) {
                spotsLeft--;
                localStorage.setItem('webinar_spots', spotsLeft);
                updateSpotsDisplay();
            }
        }, CONFIG.advanced.spotsDecreaseInterval);
    }
}

function updateSpotsDisplay() {
    const spotsLeftEl = document.getElementById('spotsLeft');
    const stickySpotsEl = document.getElementById('stickySpotsLeft');
    const progressEl = document.getElementById('spotsProgress');
    const todayCountEl = document.getElementById('todayCount');
    
    if (spotsLeftEl) spotsLeftEl.textContent = spotsLeft;
    if (stickySpotsEl) stickySpotsEl.textContent = spotsLeft;
    if (todayCountEl) todayCountEl.textContent = CONFIG.urgency.totalSpots - spotsLeft;
    
    if (progressEl) {
        const percentage = ((CONFIG.urgency.totalSpots - spotsLeft) / CONFIG.urgency.totalSpots) * 100;
        progressEl.style.width = percentage + '%';
    }
}

// ═══════════════════════════════════════════════════════════════
// 📝 FORM HANDLING
// ═══════════════════════════════════════════════════════════════

function initForm() {
    const form = document.getElementById('registrationForm');
    const phoneInput = document.getElementById('userPhone');
    const phoneError = document.getElementById('phoneError');
    
    // URL param pre-fill
    if (CONFIG.advanced.urlParamPrefill) {
        const urlParams = new URLSearchParams(window.location.search);
        const phone = urlParams.get('phone');
        const name = urlParams.get('name');
        
        if (phone && phoneInput) phoneInput.value = phone;
        if (name) {
            const nameInput = document.getElementById('userName');
            if (nameInput) nameInput.value = name;
        }
    }
    
    // Phone formatting
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 9) value = value.slice(0, 9);
            
            // Format: 90 123 45 67
            if (value.length >= 2) {
                value = value.slice(0, 2) + ' ' + value.slice(2);
            }
            if (value.length >= 7) {
                value = value.slice(0, 7) + ' ' + value.slice(7);
            }
            if (value.length >= 11) {
                value = value.slice(0, 11) + ' ' + value.slice(11);
            }
            
            e.target.value = value;
            
            // Clear error on input
            phoneError.textContent = '';
        });
    }
    
    // Form submission
    if (form) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = document.getElementById('submitButton');
            const buttonText = submitBtn.querySelector('.button-text');
            const buttonLoader = submitBtn.querySelector('.button-loader');
            const countryCode = document.getElementById('countryCode').textContent;
            const phone = phoneInput.value.replace(/\s/g, '');
            const fullPhone = countryCode + phone;
            
            // Validation
            if (phone.length < 9) {
                phoneError.textContent = CONFIG.form.phoneError;
                return;
            }
            
            // Show loading state
            submitBtn.disabled = true;
            buttonText.style.display = 'none';
            buttonLoader.style.display = 'flex';
            
            // Prepare data
            const formData = {
                phone: fullPhone,
                name: document.getElementById('userName')?.value || '',
                email: document.getElementById('userEmail')?.value || '',
                timestamp: new Date().toISOString(),
                source: window.location.href
            };
            
            try {
                // Send to webhook/API
                if (CONFIG.form.actionUrl && CONFIG.form.actionUrl !== 'https://your-webhook-url.com/submit') {
                    await fetch(CONFIG.form.actionUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(formData)
                    });
                }
                
                // Send to Telegram if configured
                if (CONFIG.form.telegramBotToken && CONFIG.form.telegramChatId) {
                    await sendToTelegram(formData);
                }
                
                // Track conversion
                trackConversion(formData);
                
                // Show success
                form.style.display = 'none';
                document.getElementById('successMessage').style.display = 'block';
                
                // Decrease spots
                if (spotsLeft > 1) {
                    spotsLeft--;
                    localStorage.setItem('webinar_spots', spotsLeft);
                    updateSpotsDisplay();
                }
                
            } catch (error) {
                console.error('Form submission error:', error);
                phoneError.textContent = CONFIG.form.errorMessage;
                
                // Reset button
                submitBtn.disabled = false;
                buttonText.style.display = 'inline';
                buttonLoader.style.display = 'none';
            }
        });
    }
}

async function sendToTelegram(data) {
    const message = `
🆕 Yangi ro'yxatdan o'tish!

📱 Telefon: ${data.phone}
👤 Ism: ${data.name || '-'}
📧 Email: ${data.email || '-'}
🕐 Vaqt: ${data.timestamp}
🔗 Manba: ${data.source}
    `;
    
    const url = `https://api.telegram.org/bot${CONFIG.form.telegramBotToken}/sendMessage`;
    
    await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            chat_id: CONFIG.form.telegramChatId,
            text: message,
            parse_mode: 'HTML'
        })
    });
}

// ═══════════════════════════════════════════════════════════════
// 🌍 COUNTRY SELECTOR
// ═══════════════════════════════════════════════════════════════

function initCountrySelector() {
    const countrySelect = document.querySelector('.country-select');
    const dropdown = document.getElementById('countryDropdown');
    const countryCode = document.getElementById('countryCode');
    const countryFlag = document.getElementById('countryFlag');
    
    if (!countrySelect || !dropdown) return;
    
    countrySelect.addEventListener('click', function(e) {
        e.stopPropagation();
        countrySelect.classList.toggle('open');
        dropdown.classList.toggle('show');
    });
    
    // Country selection
    dropdown.querySelectorAll('.country-option').forEach(option => {
        option.addEventListener('click', function(e) {
            e.stopPropagation();
            const code = this.dataset.code;
            const flag = this.dataset.flag;
            
            countryCode.textContent = code;
            countryFlag.src = flag;
            
            countrySelect.classList.remove('open');
            dropdown.classList.remove('show');
        });
    });
    
    // Close on outside click
    document.addEventListener('click', function() {
        countrySelect.classList.remove('open');
        dropdown.classList.remove('show');
    });
}

// ═══════════════════════════════════════════════════════════════
// ❓ FAQ
// ═══════════════════════════════════════════════════════════════

function initFAQ() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', function() {
            // Close others
            faqItems.forEach(other => {
                if (other !== item) {
                    other.classList.remove('open');
                }
            });
            
            // Toggle current
            item.classList.toggle('open');
        });
    });
}

function renderFAQ() {
    const container = document.getElementById('faqList');
    if (!container) return;
    
    container.innerHTML = CONFIG.faq.items.map((item, index) => `
        <div class="faq-item">
            <button class="faq-question">
                <span>${item.question}</span>
                <span class="faq-icon">+</span>
            </button>
            <div class="faq-answer">
                <p>${item.answer}</p>
            </div>
        </div>
    `).join('');
    
    // Re-init FAQ after rendering
    setTimeout(initFAQ, 100);
}

// ═══════════════════════════════════════════════════════════════
// 💬 TESTIMONIALS SLIDER
// ═══════════════════════════════════════════════════════════════

function renderTestimonials() {
    const container = document.getElementById('testimonialsSlider');
    const dotsContainer = document.getElementById('sliderDots');
    if (!container) return;
    
    container.innerHTML = CONFIG.testimonials.items.map((item, index) => `
        <div class="testimonial-card">
            <div class="testimonial-header">
                <div class="testimonial-avatar">
                    ${item.photo ? `<img src="${item.photo}" alt="${item.name}">` : '👤'}
                </div>
                <div class="testimonial-info">
                    <h4>${item.name}</h4>
                    <span class="testimonial-role">${item.role}</span>
                </div>
            </div>
            <div class="testimonial-rating">${'⭐'.repeat(item.rating)}</div>
            <p class="testimonial-text">"${item.text}"</p>
        </div>
    `).join('');
    
    // Render dots
    if (dotsContainer) {
        dotsContainer.innerHTML = CONFIG.testimonials.items.map((_, index) => `
            <span class="slider-dot ${index === 0 ? 'active' : ''}" data-index="${index}"></span>
        `).join('');
    }
}

function initTestimonialsSlider() {
    const slider = document.getElementById('testimonialsSlider');
    const dots = document.querySelectorAll('.slider-dot');
    
    if (!slider || dots.length === 0) return;
    
    let currentIndex = 0;
    
    // Scroll detection
    slider.addEventListener('scroll', function() {
        const scrollLeft = slider.scrollLeft;
        const cardWidth = slider.querySelector('.testimonial-card')?.offsetWidth || 300;
        const gap = 16;
        
        currentIndex = Math.round(scrollLeft / (cardWidth + gap));
        
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentIndex);
        });
    });
    
    // Dot click
    dots.forEach((dot, index) => {
        dot.addEventListener('click', function() {
            const cardWidth = slider.querySelector('.testimonial-card')?.offsetWidth || 300;
            const gap = 16;
            
            slider.scrollTo({
                left: index * (cardWidth + gap),
                behavior: 'smooth'
            });
        });
    });
}

// ═══════════════════════════════════════════════════════════════
// 📊 RENDER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

function renderStats() {
    const container = document.getElementById('statsGrid');
    if (!container) return;
    
    container.innerHTML = CONFIG.stats.items.map(item => `
        <div class="stat-item">
            <span class="stat-number">${item.number}</span>
            <span class="stat-label">${item.label}</span>
        </div>
    `).join('');
}

function renderBenefits() {
    const container = document.getElementById('benefitsGrid');
    if (!container) return;
    
    container.innerHTML = CONFIG.benefits.map(item => `
        <div class="benefit-card">
            <div class="benefit-icon">${item.icon}</div>
            <div class="benefit-content">
                <h3 class="benefit-title">${item.title}</h3>
                <p class="benefit-description">${item.description}</p>
            </div>
        </div>
    `).join('');
}

function renderGifts() {
    const container = document.getElementById('giftsList');
    if (!container) return;
    
    container.innerHTML = CONFIG.gifts.items.map(item => `
        <li>${item}</li>
    `).join('');
}

function renderSocialLinks() {
    const container = document.getElementById('socialLinks');
    if (!container) return;
    
    const icons = {
        telegram: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>',
        instagram: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>',
        youtube: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
        facebook: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>'
    };
    
    let html = '';
    
    Object.entries(CONFIG.social).forEach(([platform, url]) => {
        if (url && icons[platform]) {
            html += `
                <a href="${url}" class="social-link" target="_blank" rel="noopener noreferrer">
                    ${icons[platform]}
                </a>
            `;
        }
    });
    
    container.innerHTML = html;
}

// ═══════════════════════════════════════════════════════════════
// 📌 STICKY CTA
// ═══════════════════════════════════════════════════════════════

function initStickyCTA() {
    const stickyCta = document.getElementById('stickyCta');
    const hero = document.getElementById('hero');
    
    if (!stickyCta || !hero) return;
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            stickyCta.classList.toggle('visible', !entry.isIntersecting);
        });
    }, { threshold: 0 });
    
    observer.observe(hero);
}

// ═══════════════════════════════════════════════════════════════
// 🚪 EXIT INTENT
// ═══════════════════════════════════════════════════════════════

function initExitIntent() {
    if (!CONFIG.advanced.exitIntentEnabled) return;
    
    const popup = document.getElementById('exitPopup');
    const closeBtn = document.getElementById('popupClose');
    const ctaBtn = document.getElementById('popupCta');
    
    if (!popup) return;
    
    let shown = false;
    
    document.addEventListener('mouseout', function(e) {
        if (e.clientY < 10 && !shown) {
            shown = true;
            popup.style.display = 'flex';
            localStorage.setItem('exit_popup_shown', 'true');
        }
    });
    
    // Close handlers
    closeBtn?.addEventListener('click', () => {
        popup.style.display = 'none';
    });
    
    ctaBtn?.addEventListener('click', () => {
        popup.style.display = 'none';
    });
    
    popup.querySelector('.popup-overlay')?.addEventListener('click', () => {
        popup.style.display = 'none';
    });
    
    // Check if already shown
    if (localStorage.getItem('exit_popup_shown')) {
        shown = true;
    }
}

// ═══════════════════════════════════════════════════════════════
// 📊 ANALYTICS
// ═══════════════════════════════════════════════════════════════

function initAnalytics() {
    // Facebook Pixel
    if (CONFIG.analytics.facebookPixelId && CONFIG.analytics.facebookPixelId !== 'YOUR_PIXEL_ID_HERE') {
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window, document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', CONFIG.analytics.facebookPixelId);
        fbq('track', 'PageView');
        
        // Update noscript pixel
        const noscriptPixel = document.getElementById('fbPixelNoscript');
        if (noscriptPixel) {
            noscriptPixel.src = `https://www.facebook.com/tr?id=${CONFIG.analytics.facebookPixelId}&ev=PageView&noscript=1`;
        }
    }
    
    // Google Analytics
    if (CONFIG.analytics.googleAnalyticsId) {
        const script = document.createElement('script');
        script.async = true;
        script.src = `https://www.googletagmanager.com/gtag/js?id=${CONFIG.analytics.googleAnalyticsId}`;
        document.head.appendChild(script);
        
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', CONFIG.analytics.googleAnalyticsId);
    }
}

function trackConversion(data) {
    // Facebook Pixel Lead event
    if (typeof fbq !== 'undefined') {
        fbq('track', 'Lead', {
            content_name: CONFIG.webinar.headline,
            content_category: CONFIG.webinar.category
        });
    }
    
    // Google Analytics event
    if (typeof gtag !== 'undefined') {
        gtag('event', 'generate_lead', {
            event_category: 'form',
            event_label: CONFIG.webinar.headline
        });
    }
}

// ═══════════════════════════════════════════════════════════════
// 🎬 ANIMATIONS
// ═══════════════════════════════════════════════════════════════

function initAnimations() {
    if (!CONFIG.design.animationsEnabled) return;
    
    const animatedElements = document.querySelectorAll('.benefit-card, .gifts-card, .testimonial-card, .registration-card');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-on-scroll', 'visible');
            }
        });
    }, { threshold: 0.1 });
    
    animatedElements.forEach(el => {
        el.classList.add('animate-on-scroll');
        observer.observe(el);
    });
}

// ═══════════════════════════════════════════════════════════════
// 🛠️ UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════

function setText(id, text) {
    const el = document.getElementById(id);
    if (el && text !== undefined) {
        el.textContent = text;
    }
}

function setImage(id, src, alt) {
    const el = document.getElementById(id);
    if (el && src) {
        el.src = src;
        if (alt) el.alt = alt;
    }
}

function hideElement(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
}

function showElement(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'block';
}

// ═══════════════════════════════════════════════════════════════
// 🔄 AUTO-SCROLL TO FORM
// ═══════════════════════════════════════════════════════════════

if (CONFIG.advanced.autoScrollToForm) {
    setTimeout(() => {
        document.getElementById('registration')?.scrollIntoView({ 
            behavior: 'smooth' 
        });
    }, CONFIG.advanced.autoScrollDelay);
}
